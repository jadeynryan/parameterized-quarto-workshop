# Attach packages ==============================================================

library(readr)
library(here)
library(dplyr)
library(purrr)
library(quarto)
library(fs)

# Load data ====================================================================

pets <- read_rds(here("data", "pets.RDS"))

# Create dataframe to iterate over =============================================

pet_reports <- pets |>
  distinct(pet_type, breed) |>
  mutate(
    output_format = "html",
    output_file = paste(
      tolower(pet_type),
      tolower(gsub(" ", "-", breed)),
      "report.html",
      sep = "-"
    ),
    execute_params = map2(
      pet_type,
      breed,
      \(pet_type, breed) list(pet_type = pet_type, fave_breed = breed)
    )
  )

# Subset to first 2 cat/dog breeds =============================================

pet_reports_subset <- pet_reports |>
  slice_head(n = 2, by = c(pet_type, output_format)) |>
  select(output_file, output_format, execute_params)

# Map over each row ============================================================

pwalk(
  pet_reports_subset,
  quarto_render,
  input = here("ex-3-render-reports.qmd"),
  .progress = TRUE
)

# Move reports to separate folder ==============================================

output_dir <- "reports"

# List files that contain ".html".
files <- dir_ls(here(), regexp = ".html$")

# Create directory if needed
dir_create(output_dir)

# Move the files
file_move(files, output_dir)

# Exercise 3 instructions ======================================================

# 1. Modify the YAML of `ex-3-render-reports.qmd` to add a new format (pdf
# and/or docx). See the Quarto docs on multiple formats:
# https://quarto.org/docs/get-started/authoring/rstudio.html#multiple-formats.

# 2. Modify `ex-3-render-reports.R` to add this new format file extension to the
# dataframe used in `pwalk()`.

# 3. Modify the `regexp` argument in `dir_ls()` to also include ".html" OR
# ".docx" OR ".pdf". Hint: Use the `|` `OR` operator.
