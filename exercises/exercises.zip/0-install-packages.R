# Companion exercises for 2024 R-Ladies Washington DC
# Parameterized Reports with Quarto Workshop
#
# https://jadeynryan.github.io/rladies-parameterized-quarto

# Install packages used in data.R and exercises

pkgs <- c("dplyr", "fs", "ggplot2", "here", "plotly", "purrr", "quarto",
          "readr", "stringr", "janitor", "lubridate", "tidyr", "rmarkdown",
          "knitr")

install.packages(pkgs)

rm(pkgs)
